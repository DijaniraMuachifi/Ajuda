# JavaFxCrudApp
JavaFx Project that uses Sqlite, dynamics reports, Apache POI ... ...

To Login Kindly view the sqlite database "CustomerDb" using DBBrowser to see already predefined login
Feel Free to use and extend

Packaged App: https://www.dropbox.com/s/jpfh5j7byn9rsk1/CRUDAPP.rar?dl=0

Dependencies: https://www.dropbox.com/sh/1waw455ib3hmgrt/AAALIbiwoRUdqKq6l25_983Xa?dl=0

package com.example.pizza;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import com.example.pizza.Database;
public class HelloApplication extends Application {


    private final HelloController controller = new HelloController();

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        //TODO: the checks here take some time, so I would advise a splash screen
        if (Database.isOK()) {
            primaryStage.setTitle("Pizza CRUD Application");

            // TableView Setup
            TableView<Pizza> tableView = new TableView<>();
            TableColumn<Pizza, String> nameColumn = new TableColumn<>("Pizza Name");
            nameColumn.setCellValueFactory(new PropertyValueFactory<>("pname"));

            TableColumn<Pizza, String> categoryColumn = new TableColumn<>("Category");
            categoryColumn.setCellValueFactory(new PropertyValueFactory<>("categoryname"));

            TableColumn<Pizza, Boolean> vegetarianColumn = new TableColumn<>("Vegetarian");
            vegetarianColumn.setCellValueFactory(new PropertyValueFactory<>("vegetarian"));

            tableView.getColumns().addAll(nameColumn, categoryColumn, vegetarianColumn);

            // Load Data
            ObservableList<Pizza> pizzaList = controller.getAllPizzas();
            tableView.setItems(pizzaList);

            // Input Fields
            TextField nameField = new TextField();
            nameField.setPromptText("Pizza Name");
            TextField categoryField = new TextField();
            categoryField.setPromptText("Category");
            CheckBox vegetarianCheckBox = new CheckBox("Vegetarian");

            // Buttons
            Button insertButton = new Button("Insert");
            Button updateButton = new Button("Update");
            Button deleteButton = new Button("Delete");

            // Button Actions
            insertButton.setOnAction(e -> {
                String pname = nameField.getText();
                String category = categoryField.getText();
                boolean vegetarian = vegetarianCheckBox.isSelected();

                if (pname.isEmpty() || category.isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, "Form Error!", "Please enter all fields");
                    return;
                }

                Pizza newPizza = new Pizza(pname, category, vegetarian);
                controller.insertPizza(newPizza);
                tableView.getItems().add(newPizza);
                clearFields(nameField, categoryField, vegetarianCheckBox);
            });

            updateButton.setOnAction(e -> {
                Pizza selectedPizza = tableView.getSelectionModel().getSelectedItem();
                if (selectedPizza == null) {
                    showAlert(Alert.AlertType.ERROR, "Selection Error!", "Please select a pizza to update");
                    return;
                }

                String category = categoryField.getText();
                boolean vegetarian = vegetarianCheckBox.isSelected();

                if (category.isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, "Form Error!", "Please enter category");
                    return;
                }

                selectedPizza.setCategoryname(category);
                selectedPizza.setVegetarian(vegetarian);
                controller.updatePizza(selectedPizza);
                tableView.refresh();
                clearFields(nameField, categoryField, vegetarianCheckBox);
            });

            deleteButton.setOnAction(e -> {
                Pizza selectedPizza = tableView.getSelectionModel().getSelectedItem();
                if (selectedPizza == null) {
                    showAlert(Alert.AlertType.ERROR, "Selection Error!", "Please select a pizza to delete");
                    return;
                }

                controller.deletePizza(selectedPizza.getPname());
                tableView.getItems().remove(selectedPizza);
                clearFields(nameField, categoryField, vegetarianCheckBox);
            });

            // Layout Setup
            VBox layout = new VBox(10);
            layout.setPadding(new Insets(10, 10, 10, 10));
            layout.getChildren().addAll(tableView, nameField, categoryField, vegetarianCheckBox, insertButton, updateButton, deleteButton);

            Scene scene = new Scene(layout, 600, 500);
            primaryStage.setScene(scene);
            primaryStage.show();
        } else {
            System.out.println("error: database connect");
        }
    }

    private void showAlert(Alert.AlertType alertType, String s, String s1) {
    }

    private void clearFields(TextField nameField, TextField categoryField, CheckBox vegetarianCheckBox) {
    }
}
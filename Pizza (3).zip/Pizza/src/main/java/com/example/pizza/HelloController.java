package com.example.pizza;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.sql.*;

public class HelloController {
    @FXML
    private Label welcomeText;
    public ObservableList<Pizza> getAllPizzas() {
        ObservableList<Pizza> pizzaList = FXCollections.observableArrayList();
        String sql = "SELECT pname, categoryname, vegetarian FROM pizza";

        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String pname = rs.getString("pname");
                String categoryname = rs.getString("categoryname");
                boolean vegetarian = rs.getBoolean("vegetarian");
                pizzaList.add(new Pizza(pname, categoryname, vegetarian));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pizzaList;
    }

    // Inserts a new pizza into the database
    public void insertPizza(Pizza pizza) {
        String sql = "INSERT INTO pizza(pname, categoryname, vegetarian) VALUES(?,?,?)";

        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pizza.getPname());
            pstmt.setString(2, pizza.getCategoryname());
            pstmt.setBoolean(3, pizza.isVegetarian());
            pstmt.executeUpdate();
            System.out.println("Pizza inserted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Updates an existing pizza in the database
    public void updatePizza(Pizza pizza) {
        String sql = "UPDATE pizza SET categoryname = ?, vegetarian = ? WHERE pname = ?";

        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pizza.getCategoryname());
            pstmt.setBoolean(2, pizza.isVegetarian());
            pstmt.setString(3, pizza.getPname());
            pstmt.executeUpdate();
            System.out.println("Pizza updated successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Deletes a pizza from the database
    public void deletePizza(String pname) {
        String sql = "DELETE FROM pizza WHERE pname = ?";

        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pname);
            pstmt.executeUpdate();
            System.out.println("Pizza deleted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}
package com.example.pizza;

public class Pizza {
    private String pname;
    private String categoryname;
    private boolean vegetarian;

    public Pizza(String pname, String categoryname, boolean vegetarian) {
        this.pname = pname;
        this.categoryname = categoryname;
        this.vegetarian = vegetarian;
    }

    // Getters and Setters
    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public boolean isVegetarian() {
        return vegetarian;
    }

    public void setVegetarian(boolean vegetarian) {
        this.vegetarian = vegetarian;
    }
}
